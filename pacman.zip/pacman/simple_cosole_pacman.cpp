#include <iostream>
#include <Windows.h>
#include <conio.h>
#define NORTH false
#define SOUTH true
using namespace std;

short  Pacman_row = 1;

short Pacman_column = 1;

short  Pacman_row_ex = Pacman_row;

short Pacman_column_ex = Pacman_column;

short joon = 3;

bool jun = true;

int level;

int Point = 0;

bool exit_game = false;

char Keypress;



char Packman = '0';

char Map[20][35] = {
"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@",
"|  + + + + + + + + + + + + + + + |",
"|+|@@@|+|@@@@@@@@@|+|@@@@@|+|@@|+|",
"|+|   |+|         |+|     |+|  |+|",
"|+|   |+|         |+|@@@@@|+|  |+|",
"|+|   |+|         |  + + + +|  |+|",
"|+|   |+|         |+|@@@@@|+|  |+|",
"|+|@@@| |@@@@@@@@@|+|     |+|@@|+|",
"|+ + + + + + + + + +|     |+ ++ +|",
"@+|@@@@@@@@@@@|+|@|+|@@@@@|+|@@|+@",
" + + + + + + + + + + + + + + ++ +",
"@+|@@@@@@@@@@@|+|@| |@@@@@|+|@@|+@",
"|+ + + + + + + + + +|     |+ ++ +|",
"|+|@@@@@@@@@@@@@@@|+|     |+|@@|+|",
"|+|               |+|     |+|  |+|",
"|+|@@@@@@@@@@@@@@@|+|     |+|  |+|",
"|+ + + + + + + + + +|     |+|  |+|",
"|+|@@@@@@@@@@@@@@@|+|@@@@@|+|@@|+|",
"|  + + + + + + + + + + + + + + + |",
"@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@"
};

bool Walls(short& row, short& coulmn) {
	if (Map[coulmn][row] == '@') {
		return true;
	}
	else if (Map[coulmn][row] == '|') {
		return true;
	}
	return false;
}


void Check_walls(short& row, short& column, short row_ex, short column_ex) {
	if (Walls(row, column) == true) {
		row = row_ex;
		column = column_ex;

	}

}




class Ghost
{
private:
	char ghost = 'R';

	short ghost_row = 1;

	short ghost_column = 18;

	short ghost_row_ex = ghost_row;

	short ghost_column_ex = ghost_column;

	short pacman_row = 1;

	short pacman_column = 1;

	int Region;

	bool section;

	short point_row;

	short point_column;

	short point_row_ex = point_row;

	short point_column_ex = point_column;

	bool ghost_state = true;

	bool Right = true;

	bool Left = true;

	bool Up = true;

	bool Down = true;




	void Pacman_location(short row, short column) {
		pacman_row = row;
		pacman_column = column;

	};
	void move_ghost() {

		check_point_ghost(ghost_row, ghost_column);
		Map[ghost_column_ex][ghost_row_ex] = ' ';




		Check_walls(ghost_row, ghost_column, ghost_row_ex, ghost_column_ex);

		Map[ghost_column][ghost_row] = ghost;

		point_printer();


		ghost_row_ex = ghost_row;
		ghost_column_ex = ghost_column;



	}
	void check_point_ghost(short row, short column) {
		point_row_ex = point_row;
		point_column_ex = point_column;

		if (Map[column][row] == '+') {
			point_row = row;
			point_column = column;

		}

	}
	void point_printer() {

		if (ghost_row > point_row_ex) {
			Map[point_column_ex][point_row_ex] = '+';
		}
		if (ghost_row < point_row_ex) {
			Map[point_column_ex][point_row_ex] = '+';
		}
		if (ghost_column > point_column_ex) {
			Map[point_column_ex][point_row_ex] = '+';
		}
		if (ghost_column < point_column_ex) {
			Map[point_column_ex][point_row_ex] = '+';
		}
	}

	void ghost_bihavior_row_plus() {
		if (pacman_row > ghost_row) {
			ghost_row++;
			if (Walls(ghost_row, ghost_column) == true) {
				Right = false;
			}
			else
			{
				move_ghost();
			}
			if (Right == false) {
				ghost_row--;
				if (pacman_column > ghost_column) {
					ghost_column++;
					move_ghost();

				}
				else if (pacman_column < ghost_column) {
					ghost_column--;
					move_ghost();


				}
				else
				{
					while (true)
					{
						ghost_row++;
						if (Walls(ghost_row, ghost_column) == true) {
							ghost_row--;
							ghost_column++;
							move_ghost();
						}
						else
						{
							ghost_row--;
							break;
						}
						func_exit_game();
						if (jun = false) {
							break;
						}
						Sleep(level);

					}
					ghost_row++;
					move_ghost();

				}
				Right = true;
			}



		}
	}
	void ghost_bihavior_row_mines() {
		if (pacman_row < ghost_row) {
			ghost_row--;
			if (Walls(ghost_row, ghost_column) == true) {
				Left = false;
			}
			else
			{
				move_ghost();
			}
			if (Left == false) {
				ghost_row++;
				if (pacman_column > ghost_column) {

					ghost_column++;
					move_ghost();
				}
				else if (pacman_column < ghost_column) {

					ghost_column--;
					move_ghost();


				}
				else
				{
					while (true)
					{
						ghost_row--;
						if (Walls(ghost_row, ghost_column) == true) {
							ghost_row++;
							ghost_column++;
							move_ghost();
						}
						else
						{
							ghost_row++;
							break;
						}
						func_exit_game();
						if (jun = false) {
							break;
						}
						Sleep(level);

					}
					ghost_row--;
					move_ghost();

				}
				Left = true;
			}



		}

	}
	void ghost_bihavior_column_plus() {
		if (pacman_column > ghost_column) {
			ghost_column++;

			if (Walls(ghost_row, ghost_column) == true) {
				Down = false;
			}
			else
			{
				move_ghost();
				if (ghost_column == 10)
				{

				}
			}
			if (Down == false) {
				ghost_column--;
				if (pacman_row > ghost_row) {
					ghost_row++;
					move_ghost();
				}
				else if (pacman_row < ghost_row) {
					ghost_row--;
					move_ghost();


				}
				else
				{
					while (true)
					{
						ghost_column++;
						if (Walls(ghost_row, ghost_column) == true) {
							ghost_column--;
							ghost_row++;
							move_ghost();
						}
						else
						{
							ghost_column++;
							break;
						}
						func_exit_game();
						if (jun = false) {
							break;
						}

						Sleep(level);
					}
					ghost_column;
					move_ghost();

				}
				Down = true;
			}


		}

	}

	void ghost_bihavior_column_mines() {
		if (pacman_column < ghost_column) {
			ghost_column--;
			if (Walls(ghost_row, ghost_column) == true) {
				Up = false;
			}
			else
			{
				move_ghost();

			}
			if (Up == false) {
				ghost_column++;
				if (pacman_row > ghost_row) {
					ghost_row++;
					move_ghost();
				}
				else if (pacman_row < ghost_row) {
					ghost_row--;
					move_ghost();


				}
				else
				{
					while (true)
					{
						ghost_column--;
						if (Walls(ghost_row, ghost_column) == true) {
							ghost_column++;
							ghost_row++;
							move_ghost();
						}
						else
						{
							ghost_column++;
							break;
						}
						func_exit_game();
						if (jun = false) {
							break;
						}
						Sleep(level);

					}
					ghost_column--;
					move_ghost();

				}
				Up = true;
			}


		}

	}
	void func_exit_game() {

		if (Map[ghost_column][ghost_row] == '0' || Map[Pacman_column][Pacman_row] == 'R') {
			exit_game = true;
		}
	}
	void set_section() {

		if (ghost_column < Region) {

			section = NORTH;

		}
		else
		{
			section = SOUTH;
		}

	}

public:
	void initialize_ghost_row_and_column(short row, short column) {
		ghost_row = row;
		ghost_column = column;

	}


	//contructor get the posion to start in the  map 
	Ghost(short row = 1, short column = 1, int region = 10) {
		ghost_row = row;
		ghost_column = column;
		Region = region;
		Map[ghost_column][ghost_row] = ghost;

	}
	void Follow_and_grab_pacman() {

		Map[ghost_column][ghost_row] = ' ';

		set_section();
		if (section == NORTH) {
			while (true)
			{
				if (jun = false) {
					Map[ghost_column][ghost_row] = ' ';
					break;

				}
				bool state = true;
				Pacman_location(Pacman_row_ex, Pacman_column_ex);
				if (pacman_column < Region) {
					state = true;
				}
				else
				{
					state = false;

				}
				if (state == true)
				{



					while (true)
					{
						if (jun = false) {

							break;
						}

						Pacman_location(Pacman_row_ex, Pacman_column_ex);

						ghost_bihavior_row_plus();

						ghost_bihavior_row_mines();

						ghost_bihavior_column_plus();

						if (pacman_column > Region) {
							ghost_column = ghost_column_ex;
							Map[ghost_column_ex][ghost_row_ex] = ' ';
							Map[ghost_column][ghost_row] = ghost;

							ghost_row_ex = ghost_row;
							ghost_column_ex = ghost_column;
							state = false;
							break;

						}

						ghost_bihavior_column_mines();

						func_exit_game();

						Sleep(level);


					}
				}


			}
		}
		else if (section == SOUTH)
		{

			while (true)
			{

				bool state = true;
				Pacman_location(Pacman_row_ex, Pacman_column_ex);
				if (pacman_column > Region) {
					state = true;
				}
				else
				{
					state = false;

				}

				if (state == true)
				{
					Map[18][32] = ' ';

					while (true)
					{
						if (jun = false) {
							break;
						}

						Pacman_location(Pacman_row_ex, Pacman_column_ex);

						ghost_bihavior_row_plus();

						ghost_bihavior_row_mines();

						ghost_bihavior_column_plus();

						ghost_bihavior_column_mines();

						if (pacman_column < Region) {
							ghost_column = ghost_column_ex;
							Map[ghost_column_ex][ghost_row_ex] = ' ';
							Map[ghost_column][ghost_row] = ghost;

							ghost_row_ex = ghost_row;
							ghost_column_ex = ghost_column;
							state = false;
							break;

						}
						func_exit_game();

						Sleep(level);

					}
				}
				else
				{
					Map[ghost_column][ghost_row] = ghost;
				}

			}

		}
	};

};



//this function  print the map
// PrintMap, printMap, print_map
void Print_map(char map[20][35]) {
	Map[0][0] = '@';
	Map[Pacman_column][Pacman_row] = Packman;
	for (int i = 0;i < 20;i++) {
		cout << map[i] << endl;

	}
}
//this function move cursor to new postion
void Move_cursor(short row, short column) {
	HANDLE Pointer = GetStdHandle(STD_OUTPUT_HANDLE);
	COORD Position = { row , column };
	SetConsoleCursorPosition(Pointer, Position);
}

void Check_the_edges(short& row_new, short& column_new) {
	if (row_new == 33 && column_new == 10) {
		row_new = 1;

	}
	if (row_new == 0 && column_new == 10) {
		row_new = 32;

	}
}
//this function set pacman in new position
void set_pacman_in_new_position(short& row_new, short& coulmn_new) {

	Map[Pacman_column][Pacman_row] = Packman;



}
//this function delete the coulmn or row befor the pacman
void Replaceing_privios_column_or_row(short& row_ex, short& coulmn_ex) {

	Map[coulmn_ex][row_ex] = ' ';


}




void Point_counter_and_printer(short& row, short& column, int& point) {
	if (Map[column][row] == '+') {
		point += 10;
		Map[column][row] = ' ';
	}

}



void Move_pacman_to_up_or_down() {

	Replaceing_privios_column_or_row(Pacman_row_ex, Pacman_column_ex);

	Check_walls(Pacman_row, Pacman_column, Pacman_row_ex, Pacman_column_ex);

	Point_counter_and_printer(Pacman_row, Pacman_column, Point);

	set_pacman_in_new_position(Pacman_row, Pacman_column);


	Pacman_row_ex = Pacman_row;
	Pacman_column_ex = Pacman_column;

}


void Move_pacman_to_left_or_right() {

	Replaceing_privios_column_or_row(Pacman_row_ex, Pacman_column_ex);

	Check_the_edges(Pacman_row, Pacman_column);

	Check_walls(Pacman_row, Pacman_column, Pacman_row_ex, Pacman_column_ex);

	Point_counter_and_printer(Pacman_row, Pacman_column, Point);

	set_pacman_in_new_position(Pacman_row, Pacman_column);


	Pacman_row_ex = Pacman_row;
	Pacman_column_ex = Pacman_column;

}
void exitt_game() {
	if (Map[Pacman_column][Pacman_row] == 'R') {
		exit_game = true;
	}
}

void Get_keypress() {


	if (GetAsyncKeyState(87) & 1) {//W


		Keypress = 'w';



	}
	else if (GetAsyncKeyState(65) & 1) {//A


		Keypress = 'a';



	}
	else if (GetAsyncKeyState(83) & 1) {//S


		Keypress = 's';



	}
	else if (GetAsyncKeyState(68) & 1) {//D



		Keypress = 'd';



	}
}


void Act_keypress() {
	switch (Keypress)
	{
	case 'w':
		Pacman_column--;
		Move_pacman_to_up_or_down();

		Sleep(140);
		break;

	case 'a':
		Pacman_row--;
		Move_pacman_to_left_or_right();
		Sleep(120);
		break;
	case 's':
		Pacman_column++;


		Move_pacman_to_up_or_down();

		Sleep(120);
		break;
	case 'd':
		Pacman_row++;
		Move_pacman_to_left_or_right();

		Sleep(140);
		break;

	}


}

void Main_pacman() {


	if (_kbhit()) {

		Get_keypress();

	}


	Act_keypress();

	Move_cursor(0, 0);
	Print_map(Map);
	cout << "your point is: " << Point << "\n";
	cout << "joon :" << joon;




}

Ghost ghost1(32, 18);
Ghost ghost2(32, 1);


DWORD thread_ghost1(void* input) {
	ghost1.Follow_and_grab_pacman();

	return 0;
}
DWORD thread_ghost2(void* input) {
	ghost2.Follow_and_grab_pacman();

	return 0;
}

void func_ghost1() {

}
void level_detection() {
	int input;
	cout << "choose your level:\n\n" << "for Hard enter 3\n" << "for medium enter 2\n" << "for easy enter 1\n";
	cin >> input;
	switch (input)
	{
	case 1:
		level = 300;
		break;

	case 2:
		level = 200;
		break;
	case 3:
		level = 100;
		break;
	default:
		break;
	}
	system("cls");

}

int main() {
	level_detection();


	while (true)
	{



		Pacman_row = 1;

		Pacman_column = 1;
		Keypress = 's';
		ghost1.initialize_ghost_row_and_column(32, 18);
		ghost2.initialize_ghost_row_and_column(32, 1);
		Print_map(Map);
		cout << "your point is: " << Point << "\n";
		cout << "joon :" << joon;
		Keypress = _getch();
		CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)thread_ghost1, NULL, 0, NULL);
		CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)thread_ghost2, NULL, 0, NULL);






		while (true)
		{
			Main_pacman();
			if (exit_game == true) {

				joon--;
				jun = false;
				Map[Pacman_column][Pacman_row] = ' ';

				system("cls");
				cout << "you lost one joon\n\n" << "press any key to continu";



				exit_game = false;
				char any = _getch();
				system("cls");
				break;
			}
			if (Point >= 1440) {
				system("cls");
				cout << "CONGRATUlATIONS YOU WIN\n\n\n";
				break;
			}



		}
		if (Point >= 1440) {
			system("cls");
			cout << "CONGRATUlATIONS YOU WIN\n\n\n";
			break;
		}
		if (joon < 0) {
			cout << "SORRY YOU LOST";
			break;
		}
		else
		{
			jun = true;
		}
	}
	char m = _getch();

}









